import numpy
import math
import os
np = numpy
from numpy import sin,cos,exp,log
import pylab
import matplotlib.pyplot as plt

import subprocess
import sys


# the folder where to store 
# the images
out_folder = "/home/tbeier/Desktop/fischer/out"



# optional crop 
# all figures
import os
for file in os.listdir(out_folder):
    if file.endswith(".pdf"):
        f = os.path.join(out_folder, file)

        subprocess.call(["pdfcrop", f,f])
