import numpy
import math
import os
np = numpy
from numpy import sin,cos,exp,log
import pylab
import matplotlib.pyplot as plt


import sys


# the folder where to store 
# the images
out_folder = "/home/tbeier/Desktop/fischer/out"


# problem parameter
std = 0.2


# plotting quality 
numR = 60
numPhi = 55
rBegin = -7.0
rEnd = abs(rBegin)
linspaceR = numpy.linspace(rBegin,rEnd,num=numR)
linspacePhi = numpy.linspace(0,2.0*numpy.pi,num=numPhi)





def setAxisLabels(ax):
    global numR,numPhi,rEnd

    # for axis labels y
    tmp = float(numR-1)
    y_ticks = [0.0,0.25*tmp, 0.5*tmp, 0.75*tmp, tmp]
    y_ticks_labels = [
        '-%s'%rEnd,
        '-%s/2'%rEnd,
        '0',
        '+%s/2'%rEnd,
        '+%s'%rEnd  
    ]

    # for axis labels x
    tmp = float(numPhi-1)/2
    x_ticks = [0, 0.5*tmp, tmp, 1.5*tmp, 2.0*tmp]
    x_ticks_labels = ['0','0.5 PI','1.0 PI','1.5 PI', '2.0 PI']

    ax.set_xticks(x_ticks)
    ax.set_xticklabels(x_ticks_labels)
    ax.set_yticks(y_ticks)
    ax.set_yticklabels(y_ticks_labels)


def make_ds(x0, size=1000, std=0.1):

    ax0 = numpy.random.normal(x0,std, size=size)
    ax1 = numpy.random.normal(1,std, size=size)

    cluster0 = numpy.array([ax0,ax1]).T

    bx0 = numpy.random.normal(x0,std, size=size)
    bx1 = numpy.random.normal(2,std, size=size)

    cluster1 = numpy.array([bx0,bx1]).T


    X = numpy.concatenate([cluster0, cluster1]).astype('float64')
    Y = numpy.concatenate([numpy.zeros(size), numpy.ones(size)])
    assert X.shape[0] == size*2
    assert X.shape[1] == 2
    assert Y.shape[0] == size*2

    return X,Y


cc = 1

for ii,x0 in enumerate([1.0, 5.0]):


    X,Y = make_ds(x0=x0,size=1000, std=std)#25)

    # give this dataset a name such that
    # we can save it to disc
    ds_name = "ds_x0=%f_std=%f"%(x0,std)

    # plot the dataset
    plt.figure()
    plt.scatter(X[:, 0], X[:, 1], marker='o', c=Y)
    plt.axis('equal')
    #plt.show()
    plt.savefig(os.path.join(out_folder,'scatter_%s.pdf')%ds_name)



    #sys.exit()

    def my_sigmoid(x):
        return 1.0 / (1.0 + numpy.exp(-1.0*x))

    def compute_z(X, r, phi):
        assert X.shape[1] == 2
        a = X[:,0]
        b = X[:,1]
        return my_sigmoid( a*math.sin(phi) + b*math.cos(phi) + r)





    def get_loss_and_hamming_error(Z,Y):

        prediction_p1 = Z
        prediction_p0 = 1.0 - Z

        true_p0 = 1.0 - Y.astype('float64')
        true_p1 = Y.astype('float64')



        loss = true_p0 * numpy.log(prediction_p0) + true_p1 * numpy.log(prediction_p1)  
        loss = -1.0*loss.mean()
        
        prediction_y = numpy.round(prediction_p1)
        hamming =  numpy.mean(numpy.abs(Y-prediction_y))

        return loss, hamming




    # we use r as first parameter
    # and phi as second in the fischer matrix!
    def getFischerMat(X, phi, r):

        # number of samples
        n = X.shape[0]

        # shortcuts for x0 and x1
        a = X[:,0] # x0
        b = X[:,1] # x1

        # z and 1-z (aka mz)
        z = compute_z(X, phi=phi, r=r)
        mz = 1.0 - z

        # d log z / d r
        drz   =   1.0 / (exp(a*sin(phi) + b*cos(phi) + r) + 1.0)
        # d log z / d phi
        dphiz =   (a*cos(phi)-b*sin(phi)) / (exp(a*sin(phi) + b*cos(phi)+r) + 1.0 )

        # d log 1-z / d r
        drmz = -1.0*exp(a*sin(phi) + b*cos(phi) + r)/(exp(a*sin(phi) + b*cos(phi) + r)+1.0)

        # d log 1-z / d phi
        dphimz = (b*sin(phi)-a*cos(phi))*exp(a*sin(phi) + b*cos(phi) + r) / \
            (exp(a*sin(phi) + b*cos(phi)+r)+1.0)


        # I am not totally sure if we 
        # need / should divide by the
        # number of samples
        # BUT IF WE DO we get numeric issues

        fPhi  =  (np.sum(dphiz**2 * z) + np.sum(dphimz**2 * mz))
        fR    =  (np.sum(drz**2   * z) + np.sum(drmz**2   * mz))
        fRPhi =  (np.sum(drz*dphiz*z)  + np.sum(dphimz*drmz* mz))

        
        return numpy.array([[fR,fRPhi],[fRPhi,fPhi]])


    def compute_grad(X,Y,phi,r):
        a = X[:,0]
        b = X[:,1]
        y = Y.astype('float64')


        tmp1 = (a*cos(phi)-b*sin(phi))
        tmp2 = (1.0-y)*exp(a*sin(phi)+b*cos(phi) +r) + y
        tmp3 = exp(a*sin(phi)+b*cos(phi)+r) + 1.0

        # dl / dphi 
        dldphi = -1.0 * (tmp1*tmp2)/(tmp3)
        dldphi = numpy.mean(dldphi)

        
        tmp4 = (1.0-y)*exp(a*sin(phi)+b*cos(phi) +r) - y
        tmp5 = tmp3 

        # dl / dr
        dldr = tmp4/tmp5
        dldr = numpy.mean(dldr)
        return dldphi, dldr
        

    # do gradient decent and remember all parameters to plot them later
    #  starting point

    r_start = -1.0
    phi_start = 0.99*numpy.pi


    r =  r_start
    phi = phi_start

    history = [(r,phi)]
    if True:
        step_size = 0.25
        for step in range(2000):
            
            dldphi,dldr = compute_grad(X,Y,phi=phi,r=r)
            Z = compute_z(X, phi=phi,r=r)
            loss, hamming_error = get_loss_and_hamming_error(Z=Z,Y=Y)
            r -= step_size*dldr
            phi -= step_size*dldphi
            history.append((r,phi))
    history = numpy.array(history)
    print(history.shape)


    # do Natural gradient decent and remember all parameters to plot them later
    #  starting point
    r =  r_start
    phi = phi_start

    history_nat = [(r,phi)]
    if True:
        step_size = 0.25
        for step in range(8000):
            
            dldphi,dldr = compute_grad(X,Y,phi=phi,r=r)
            Z = compute_z(X, phi=phi,r=r)
            loss, hamming_error = get_loss_and_hamming_error(Z=Z,Y=Y)

            g = numpy.array([dldr,dldphi])
            f = getFischerMat(X=X, r=r, phi=phi)
            iF = numpy.linalg.inv(f)
            nG = numpy.matmul(iF,g.T)

            r -= step_size*nG[0]
            phi -= step_size*nG[1]


            history_nat.append((r,phi))
    history_nat = numpy.array(history_nat)




    # compute gradient and natural
    # gradient for all points on the grid
    if True:

        # the normal gradient
        gPhi = numpy.zeros([numR, numPhi])
        gR   = numpy.zeros([numR, numPhi])

        # the natural gradient
        gNatPhi = numpy.zeros([numR, numPhi])
        gNatR   = numpy.zeros([numR, numPhi])



        fischerMatrix = numpy.zeros([numR, numPhi,2,2])

        for ir, r in enumerate(linspaceR):
            for iphi, phi in enumerate(linspacePhi):

                dldphi, dldr = compute_grad(X,Y,phi=phi,r=r)
                # store gradient in arrays
                gPhi[ir, iphi] = dldphi
                gR[ir, iphi] = dldr

                # gradient as vector
                g = numpy.array([dldr,dldphi])
                fMat = getFischerMat(X=X, r=r, phi=phi)

                # store the fischer mat
                fischerMatrix[ir, iphi,:,:] = fMat

                # invert
                iF = numpy.linalg.inv(fMat)
                gNat = numpy.matmul(iF,g)

                # store natural  gradient 
                # as array
                gNatPhi[ir, iphi] = gNat[1]
                gNatR[ir, iphi] = gNat[0]






    if True:
        loss_array = numpy.zeros([numR, numPhi])
        hamming_error_array =  numpy.zeros([numR, numPhi])

        for ir, r in enumerate(linspaceR):
            for iphi, phi in enumerate(linspacePhi):

                Z = compute_z(X,r=r,phi=phi)

                loss, hamming_error = get_loss_and_hamming_error(Z=Z, Y=Y)   
                loss_array[ir,iphi] = loss
                hamming_error_array[ir,iphi] = hamming_error






    






    # transform to ``plot-coordinates``
    hist_r = float(numR)*(history[:,0] - rBegin)/(rEnd-rBegin)
    hist_phi = (float(numPhi)*(history[:,1])/(numpy.pi*2)) 
    hist_nat_r = float(numR)*(history_nat[:,0] - rBegin)/(rEnd-rBegin)
    hist_nat_phi = (float(numPhi)*(history_nat[:,1])/(numpy.pi*2))  



    #################################################################
    # This Plot Shows:
    #   Loss HeatMap
    #   Loss IsoContours
    #   Gradient VectorField
    #   GradientDecent + NaturalGradientDecent
   
    fig, ax = plt.subplots()
    plot = ax.imshow(loss_array,interpolation='None')
    plt.colorbar(plot,ax=ax)
    ax.autoscale(False)
    setAxisLabels(ax)
    ax.quiver(gPhi, gR, width=0.002,linewidth=0.091, angles='xy')
    a=ax.plot(hist_phi[0], hist_r[0], marker='o', markersize=3.5, color="black")
    ax.plot(hist_phi[-1], hist_r[-1], marker='o', markersize=3.5, color="blue")
    ax.plot(hist_nat_phi[-1], hist_nat_r[-1], marker='o', markersize=3.5, color="blue")
    ax.plot(hist_phi,hist_r,c='green',marker='o', markersize=0.7, markeredgecolor='black')
    ax.plot(hist_nat_phi,hist_nat_r,c='red',marker='o', markersize=0.7, markeredgecolor='black')
    ax.contour(loss_array,interpolation='None',colors='black', alpha=0.2)
    #plt.title('Grad. (grad=green, nat.grad=red)')
    fig.tight_layout()
    plt.savefig(os.path.join(out_folder,'loss_grad_%s.pdf')%ds_name)
    

    #################################################################
    # This Plot Shows:
    #   angle of  gradient
    #   Loss IsoContours
    #   Gradient VectorField
    #   GradientDecent + NaturalGradientDecent
    aGrad = np.arctan2(gPhi, gR)
    hist_r = float(numR)*(history[:,0] - rBegin)/(rEnd-rBegin)
    hist_phi = float(numPhi)*(history[:,1])/(numpy.pi*2)
    hist_nat_r = float(numR)*(history_nat[:,0] - rBegin)/(rEnd-rBegin)
    hist_nat_phi = float(numPhi)*(history_nat[:,1])/(numpy.pi*2)
    fig, ax = plt.subplots()
    plot = ax.imshow(aGrad,cmap='hsv')#,interpolation='None')
    plt.colorbar(plot,ax=ax)
    ax.autoscale(False)
    setAxisLabels(ax)
    ax.quiver(gPhi,gR, 
        width=0.001,linewidth=0.091, angles='xy',minshaft=2.0)
    ax.plot(hist_phi[0], hist_r[0], marker='o', markersize=3.5, color="black")
    ax.plot(hist_phi[-1], hist_r[-1], marker='o', markersize=3.5, color="blue")
    ax.plot(hist_nat_phi[-1], hist_nat_r[-1], marker='o', markersize=3.5, color="blue")
    ax.plot(hist_phi,hist_r,c='green',marker='o', markersize=0.7, markeredgecolor='black')
    ax.plot(hist_nat_phi,hist_nat_r,c='red',marker='o', markersize=0.7, markeredgecolor='black')
    ax.contour(loss_array,interpolation='None',colors='black', alpha=0.2)
    #plt.title('NatGradAngle (grad=green, nat-grad=red)')
    fig.tight_layout()
    plt.savefig(os.path.join(out_folder,'angle_grad_%s.pdf')%ds_name)
    
    #################################################################
    # This Plot Shows:
    #   magnitude of  gradient
    #   Loss IsoContours
    #   Gradient VectorField
    #   GradientDecent + NaturalGradientDecent
    aMag = np.sqrt(gPhi**2, gR**2)
    hist_r = float(numR)*(history[:,0] - rBegin)/(rEnd-rBegin)
    hist_phi = float(numPhi)*(history[:,1])/(numpy.pi*2)
    hist_nat_r = float(numR)*(history_nat[:,0] - rBegin)/(rEnd-rBegin)
    hist_nat_phi = float(numPhi)*(history_nat[:,1])/(numpy.pi*2)
    fig, ax = plt.subplots()
    plot = ax.imshow(aMag)#,interpolation='None')
    plt.colorbar(plot,ax=ax)
    ax.autoscale(False)
    setAxisLabels(ax)
    ax.quiver(gPhi,gR, 
        width=0.001,linewidth=0.091, angles='xy',minshaft=2.0)
    ax.plot(hist_phi[0], hist_r[0], marker='o', markersize=3.5, color="black")
    ax.plot(hist_phi[-1], hist_r[-1], marker='o', markersize=3.5, color="blue")
    ax.plot(hist_nat_phi[-1], hist_nat_r[-1], marker='o', markersize=3.5, color="blue")
    ax.plot(hist_phi,hist_r,c='green',marker='o', markersize=0.7, markeredgecolor='black')
    ax.plot(hist_nat_phi,hist_nat_r,c='red',marker='o', markersize=0.7, markeredgecolor='black')
    ax.contour(loss_array,interpolation='None',colors='black', alpha=0.2)
    #plt.title('NatGradAngle (grad=green, nat-grad=red)')
    fig.tight_layout()
    plt.savefig(os.path.join(out_folder,'magnitude_grad_%s.pdf')%ds_name)

    #################################################################
    # This Plot Shows:
    #   Loss HeatMap
    #   Loss IsoContours
    #   Natural Gradient VectorField
    #   GradientDecent + NaturalGradientDecent
    fig, ax = plt.subplots()
    plot = ax.imshow(loss_array,interpolation='None')
    plt.colorbar(plot,ax=ax)
    ax.autoscale(False)
    setAxisLabels(ax)
    ax.quiver(gNatPhi,gNatR, 
        width=0.001,linewidth=0.091, angles='xy',minshaft=2.0)
    ax.plot(hist_phi[0], hist_r[0], marker='o', markersize=3.5, color="black")
    ax.plot(hist_phi[-1], hist_r[-1], marker='o', markersize=3.5, color="blue")
    ax.plot(hist_nat_phi[-1], hist_nat_r[-1], marker='o', markersize=3.5, color="blue")
    ax.plot(hist_phi,hist_r,c='green',marker='o', markersize=0.7, markeredgecolor='black')
    ax.plot(hist_nat_phi,hist_nat_r,c='red',marker='o', markersize=0.7, markeredgecolor='black')
    ax.contour(loss_array,interpolation='None',colors='black', alpha=0.2)
    #plt.title('NatGrad (grad=green, nat-grad=red)')
    fig.tight_layout()
    plt.savefig(os.path.join(out_folder,'loss_ngrad_%s.pdf')%ds_name)
    

    
    #################################################################
    # This Plot Shows:
    #   angle of natural gradient
    #   Loss IsoContours
    #   Natural Gradient VectorField
    #   GradientDecent + NaturalGradientDecent
    aNat = np.arctan2(gNatPhi, gNatR)
    hist_r = float(numR)*(history[:,0] - rBegin)/(rEnd-rBegin)
    hist_phi = float(numPhi)*(history[:,1])/(numpy.pi*2)
    hist_nat_r = float(numR)*(history_nat[:,0] - rBegin)/(rEnd-rBegin)
    hist_nat_phi = float(numPhi)*(history_nat[:,1])/(numpy.pi*2)
    fig, ax = plt.subplots()
    plot = ax.imshow(aNat,cmap='hsv')#,interpolation='None')
    plt.colorbar(plot,ax=ax)
    ax.autoscale(False)
    setAxisLabels(ax)
    ax.quiver(gNatPhi,gNatR, 
        width=0.001,linewidth=0.091, angles='xy',minshaft=2.0)
    ax.plot(hist_phi[0], hist_r[0], marker='o', markersize=3.5, color="black")
    ax.plot(hist_phi[-1], hist_r[-1], marker='o', markersize=3.5, color="blue")
    ax.plot(hist_nat_phi[-1], hist_nat_r[-1], marker='o', markersize=3.5, color="blue")
    ax.plot(hist_phi,hist_r,c='green',marker='o', markersize=0.7, markeredgecolor='black')
    ax.plot(hist_nat_phi,hist_nat_r,c='red',marker='o', markersize=0.7, markeredgecolor='black')
    ax.contour(loss_array,interpolation='None',colors='black', alpha=0.2)
    #plt.title('NatGradAngle (grad=green, nat-grad=red)')
    fig.tight_layout()
    plt.savefig(os.path.join(out_folder,'angle_ngrad_%s.pdf')%ds_name)

    
    #################################################################
    # This Plot Shows:
    #   magnitude of natural gradient
    #   Loss IsoContours
    #   Natural Gradient VectorField
    #   GradientDecent + NaturalGradientDecent
    aMag = np.sqrt(gNatPhi**2, gNatR**2)
    hist_r = float(numR)*(history[:,0] - rBegin)/(rEnd-rBegin)
    hist_phi = float(numPhi)*(history[:,1])/(numpy.pi*2)
    hist_nat_r = float(numR)*(history_nat[:,0] - rBegin)/(rEnd-rBegin)
    hist_nat_phi = float(numPhi)*(history_nat[:,1])/(numpy.pi*2)
    fig, ax = plt.subplots()
    plot = ax.imshow(aMag,interpolation='None')
    plt.colorbar(plot,ax=ax)
    ax.autoscale(False)
    setAxisLabels(ax)
    ax.quiver(gNatPhi,gNatR, 
        width=0.001,linewidth=0.091, angles='xy',minshaft=2.0)
    ax.plot(hist_phi[0], hist_r[0], marker='o', markersize=3.5, color="black")
    ax.plot(hist_phi[-1], hist_r[-1], marker='o', markersize=3.5, color="blue")
    ax.plot(hist_nat_phi[-1], hist_nat_r[-1], marker='o', markersize=3.5, color="blue")
    ax.plot(hist_phi,hist_r,c='green',marker='o', markersize=0.7, markeredgecolor='black')
    ax.plot(hist_nat_phi,hist_nat_r,c='red',marker='o', markersize=0.7, markeredgecolor='black')
    ax.contour(loss_array,interpolation='None',colors='black', alpha=0.2)
    #plt.title('NatGradAngle (grad=green, nat-grad=red)')
    fig.tight_layout()
    plt.savefig(os.path.join(out_folder,'magnitude_ngrad_%s.pdf')%ds_name)



    #################################################################
    # This Plot Shows:
    #   FischerInformation_Phi,Phi
    hist_r = float(numR)*(history[:,0] - rBegin)/(rEnd-rBegin)
    hist_phi = float(numPhi)*(history[:,1])/(numpy.pi*2)
    hist_nat_r = float(numR)*(history_nat[:,0] - rBegin)/(rEnd-rBegin)
    hist_nat_phi = float(numPhi)*(history_nat[:,1])/(numpy.pi*2)
    fig, ax = plt.subplots()
    plot = ax.imshow(fischerMatrix[:,:,1,1],interpolation='None')
    plt.colorbar(plot,ax=ax)
    ax.autoscale(False)
    setAxisLabels(ax)
    ax.plot(hist_phi[0], hist_r[0], marker='o', markersize=3.5, color="black")
    ax.plot(hist_phi[-1], hist_r[-1], marker='o', markersize=3.5, color="blue")
    ax.plot(hist_nat_phi[-1], hist_nat_r[-1], marker='o', markersize=3.5, color="blue")
    ax.plot(hist_phi,hist_r,c='green',marker='o', markersize=0.7, markeredgecolor='black')
    ax.plot(hist_nat_phi,hist_nat_r,c='red',marker='o', markersize=0.7, markeredgecolor='black')
    #plt.title('FischerMat_PhiPhi (grad=green, nat-grad=red)')
    fig.tight_layout()
    plt.savefig(os.path.join(out_folder,'fischer_phi_phi_%s.pdf')%ds_name)


    #################################################################
    # This Plot Shows:
    #   FischerInformation_R,R
    hist_r = float(numR)*(history[:,0] - rBegin)/(rEnd-rBegin)
    hist_phi = float(numPhi)*(history[:,1])/(numpy.pi*2)
    hist_nat_r = float(numR)*(history_nat[:,0] - rBegin)/(rEnd-rBegin)
    hist_nat_phi = float(numPhi)*(history_nat[:,1])/(numpy.pi*2)
    fig, ax = plt.subplots()
    plot = ax.imshow(fischerMatrix[:,:,0,0],interpolation='None')
    plt.colorbar(plot,ax=ax)
    ax.autoscale(False)
    setAxisLabels(ax)
    ax.plot(hist_phi[0], hist_r[0], marker='o', markersize=3.5, color="black")
    ax.plot(hist_phi[-1], hist_r[-1], marker='o', markersize=3.5, color="blue")
    ax.plot(hist_nat_phi[-1], hist_nat_r[-1], marker='o', markersize=3.5, color="blue")
    ax.plot(hist_phi,hist_r,c='green',marker='o', markersize=0.7, markeredgecolor='black')
    ax.plot(hist_nat_phi,hist_nat_r,c='red',marker='o', markersize=0.7, markeredgecolor='black')
    #plt.title('FischerMat_RR (grad=green, nat-grad=red)')
    fig.tight_layout()
    plt.savefig(os.path.join(out_folder,'fischer_r_r_%s.pdf')%ds_name)


    #################################################################
    # This Plot Shows:
    #   FischerInformation_R,PHI
    hist_r = float(numR)*(history[:,0] - rBegin)/(rEnd-rBegin)
    hist_phi = float(numPhi)*(history[:,1])/(numpy.pi*2)
    hist_nat_r = float(numR)*(history_nat[:,0] - rBegin)/(rEnd-rBegin)
    hist_nat_phi = float(numPhi)*(history_nat[:,1])/(numpy.pi*2)
    fig, ax = plt.subplots()
    plot = ax.imshow(fischerMatrix[:,:,0,1],interpolation='None')
    plt.colorbar(plot,ax=ax)
    ax.autoscale(False)
    setAxisLabels(ax)
    ax.plot(hist_phi[0], hist_r[0], marker='o', markersize=3.5, color="black")
    ax.plot(hist_phi[-1], hist_r[-1], marker='o', markersize=3.5, color="blue")
    ax.plot(hist_nat_phi[-1], hist_nat_r[-1], marker='o', markersize=3.5, color="blue")
    ax.plot(hist_phi,hist_r,c='green',marker='o', markersize=0.7, markeredgecolor='black')
    ax.plot(hist_nat_phi,hist_nat_r,c='red',marker='o', markersize=0.7, markeredgecolor='black')
    #plt.title('FischerMat_RPhi (grad=green, nat-grad=red)')
    fig.tight_layout()
    plt.savefig(os.path.join(out_folder,'fischer_r_phi_%s.pdf')%ds_name)



# optional crop 
